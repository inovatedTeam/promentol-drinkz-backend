module.exports = {
  "production": {
    "use_env_variable": "DATABASE_URL",
    "secretKey": "asndkjasndkln",
    "baseUrl": "http://secret-dawn-5731.herokuapp.com",
    "twitter": {
       "key": "QcaBBr7oh1qaNA5P7PpZsqS7k",
      "secret": "ps4nmSUvQ3AwVAEz9f5LZj3Wlm3vihHR7X1t4pikzpnDQkFu2f"
    },
    "aws": {
      "accessKeyId": "AKIAIIZNMMENMSZNVBEA",
      "secretAccessKey": "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",
      "bucket": "drinkz",
      "server": "s3.amazonaws.com"
    },
    "sendGrid": {
      "user": process.env.SENDGRID_USERNAME || "app38449634@heroku.com",
      "password": process.env.SENDGRID_PASSWORD || "5qyqsr5z0092"
    }
  },
  "development": {
    "username": "postgres",
    "password": "postgres",
    "database": "drinkz",
    "host": "192.168.99.101",
    "dialect": "postgres",
    "omitNull": true,
    "secretKey": "asdqwe",
    "baseUrl": "http://localhost:3000",
    "twitter": {
      "key": "QcaBBr7oh1qaNA5P7PpZsqS7k",
      "secret": "ps4nmSUvQ3AwVAEz9f5LZj3Wlm3vihHR7X1t4pikzpnDQkFu2f"
    },
    "aws": {
      "accessKeyId": "AKIAIIZNMMENMSZNVBEA",
      "secretAccessKey": "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",
      "bucket": "drinkz-development",
      "server": "s3.amazonaws.com"
    },
    "sendGrid": {
      "user": process.env.SENDGRID_USERNAME || "app38449634@heroku.com",
      "password": process.env.SENDGRID_PASSWORD || "5qyqsr5z0092"
    }
  }
};