"use strict";

var exports = {};

var Region = require('../models').Region;

exports.getAllRegions = function(q){
    var whereCause = {};
    if(q){
        whereCause.name = whereCause.name || {};
        whereCause.name.ilike =  '%'+q+'%';
    }
    return Region.findAll({
        where: whereCause
    });
};

module.exports = exports;