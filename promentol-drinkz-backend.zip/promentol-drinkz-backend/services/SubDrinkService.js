"use strict";

var Promise = require('bluebird');
var SubDrink = require('../models').SubDrink;
var models = require('../models');
var validator = require('validator');
var exports = {};

exports.searchSubDrinks = function(searchData){
    var whereCause = {};
    if(searchData.drinkId && validator.isInt(searchData.drinkId)){
        whereCause.drinkId = searchData.drinkId;
    }
    return SubDrink.findAll({
        where: whereCause
    });
};

module.exports = exports;