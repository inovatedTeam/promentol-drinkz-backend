"use strict";

var exports = {};

var Venue = require('../models').Venue;

exports.getAllVenues = function(q, regions){
    var whereCause = {};
    if(q){
        whereCause.name = whereCause.name || {};
        whereCause.name.ilike =  '%'+q+'%';
    }
    if(regions){
        if(typeof regions != 'object') regions = [regions];
        whereCause.regionId = whereCause.regionId || {};
        whereCause.regionId.$in = regions;
    }
    return Venue.findAll({
        where: whereCause
    });
};

module.exports = exports;