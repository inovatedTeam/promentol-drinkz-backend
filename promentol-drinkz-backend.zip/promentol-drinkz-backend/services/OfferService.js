"use strict";

var Promise = require('bluebird');
var Offer = require('../models').Offer;
var Venue = require('../models').Venue;
var Media = require('../models').Media;
var Product = require('../models').Product;
var VenueOffer = require('../models').VenueOffer;
var models = require('../models');
var validator = require('validator');
var exports = {};
var async = require('async');
var UserService = require('./UserService');

exports.createOffer = function(params, user){
    var whereCause = {};
    if(!params.mediaId){
        throw {
            name: 'SequelizeValidationError',
            errors: [
                {
                    path: 'mediaId',
                    message: 'drinkz.offers.error.media.empty'
                }
            ]
        }
    }
    return Media.find({
        where:{
            id: params.mediaId
        }
    }).then(function(media){
        if(!media){
            throw {
                name: 'SequelizeValidationError',
                errors: [
                    {
                        path: 'mediaId',
                        message: 'drinkz.offers.error.media.invalid'
                    }
                ]
            }
        }
        if(!params.productId){
            throw {
                name: 'SequelizeValidationError',
                errors: [
                    {
                        path: 'productId',
                        message: 'drinkz.offers.error.product.empty'
                    }
                ]
            }
        }
        return Product.find({
            where: {
                id: params.productId
            }
        }).then(function(product){
            if(!product){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'productId',
                            message: 'drinkz.offers.error.product.invalid'
                        }
                    ]
                }
            }
            if(!params.expireDate){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'expireDate',
                            message: 'drinkz.offers.error.expireDate.empty'
                        }
                    ]
                }
            }
            if(!validator.isDate(params.expireDate)){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'expireDate',
                            message: 'drinkz.offers.error.expireDate.invalid'
                        }
                    ]
                }
            }
            params.quantity = parseInt(params.quantity);
            if(!validator.isInt(params.quantity) || params.quantity<=0){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'quantity',
                            message: 'drinkz.offers.error.quantity.invalid'
                        }
                    ]
                }
            }
            if(!validator.isIn(params.drink, ["product", "cocktail"])){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'quantity',
                            message: 'drinkz.offers.error.drink.invalid'
                        }
                    ]
                }
            }
            return VenueOffer.build({
                quantity: params.quantity,
                expireDate: params.expireDate,
                createdBy: user.id,
                mediaId: params.mediaId,
                productId: params.productId
            }).save();
        });
    });
};

exports.createVenueOffer = function(params, user){
    var whereCause = {};
    if(params.venues && params.venues.length){
        whereCause.id = {
            $in: params.venues
        }
    } else if(params.venues){
        whereCause.id = params.venue;
    }
    return Venue.findAll({
        where: whereCause
    }).then(function(venues){
        if(!venues.length){
            throw {
                name: 'SequelizeValidationError',
                errors: [
                    {
                        path: 'venues',
                        message: 'drinkz.offers.error.venues.invalid'
                    }
                ]
            }
        }
        if(!params.mediaId){
            throw {
                name: 'SequelizeValidationError',
                errors: [
                    {
                        path: 'mediaId',
                        message: 'drinkz.offers.error.media.empty'
                    }
                ]
            }
        }
        return Media.find({
            where:{
                id: params.mediaId
            }
        }).then(function(media){
            if(!media){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'mediaId',
                            message: 'drinkz.offers.error.media.invalid'
                        }
                    ]
                }
            }
            if(!params.productId){
                throw {
                    name: 'SequelizeValidationError',
                    errors: [
                        {
                            path: 'productId',
                            message: 'drinkz.offers.error.product.empty'
                        }
                    ]
                }
            }
            return Product.find({
                where: {
                    id: params.productId
                }
            }).then(function(product){
                if(!product){
                    throw {
                        name: 'SequelizeValidationError',
                        errors: [
                            {
                                path: 'productId',
                                message: 'drinkz.offers.error.product.invalid'
                            }
                        ]
                    }
                }
                if(!validator.isDate(params.expireDate)){
                    throw {
                        name: 'SequelizeValidationError',
                        errors: [
                            {
                                path: 'expireDate',
                                message: 'drinkz.offers.error.expireDate.invalid'
                            }
                        ]
                    }
                }
                params.quantity = parseInt(params.quantity);
                if(!validator.isInt(params.quantity) || params.quantity<=0){
                    throw {
                        name: 'SequelizeValidationError',
                        errors: [
                            {
                                path: 'quantity',
                                message: 'drinkz.offers.error.quantity.invalid'
                            }
                        ]
                    }
                }
                return VenueOffer.build({
                    quantity: params.quantity,
                    expireDate: params.expireDate,
                    createdBy: user.id,
                    mediaId: params.mediaId,
                    productId: params.productId,
                    publishDate: new Date()
                }).save().then(function(offer){
                    return offer.setVenues(venues).then(function(){
                        return offer;
                    });
                });
            });
        });
    });
};

exports.getOffersForVenue = function(user){
    return new Promise(function(resolve, reject){
        Venue.find({
            where: {
                userId: user.id
            },
            include: {
                model: VenueOffer,
                include: [
                    {
                        model: models.Media
                    },{
                        model: models.Product,
                        include: [models.SubDrink]
                    },
                    {
                        model: models.User,
                        include: [models.DrinkProvider]
                    }
                ]
            }
        }).then(function(venue){
            async.filter(venue.VenueOffers, function(x, cb){
                cb( x.OfferToVenue.status == 0 );
            }, function(x){
                resolve(x);
            });
        }).catch(function(x){
            reject(x);
        });
    });
};

exports.getOffersFromVenue = function(user){
    return Offer.findAll({
        where: {
            createdBy: user.id
        },
        include: [
            models.Media,
            {
                model: models.Product,
                include: [models.SubDrink]
            },
            models.Venue
        ]
    });
};

exports.claimOffer = function(offerId, user){
    return Offer.find({
        where: {
            id: offerId
        },
        include: {
            model: models.User,
            required: false,
            where: {
                id: user.id
            }
        }
    }).then(function(offer) {
        if (!offer) {
            throw {
                status: 404
            }
        }
        if (offer.Users && offer.Users.length) {
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.alreadyClaimed'
            }
        }
        if (offer.claimsCount >= offer.quantity) {
            throw {
                name: 'Client',
                path: 'quantity',
                message: 'drinkz.offers.error.quantity.notAvailable'
            }
        }
        return offer.updateAttributes({
            claimsCount: offer.claimsCount + 1
        }).then(function () {
            return UserService.getUser(user).then(function (user) {
                return offer.addUser(user, {
                    status: 1,
                    claimDate: new Date()
                });
            });
        });
    });
};

exports.startRedeem = function(offerId, user){
    return Offer.find({
        where: {
            id: offerId
        },
        include: {
            model: models.User,
            required: false,
            where: {
                id: user.id
            }
        }
    }).then(function(offer){
        if(!offer){
            throw {
                status: 404
            }
        }
        if(!offer.Users.length){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.notClaimed'
            }
        }
        if(offer.Users[0].OfferToUser.status != 1 && offer.Users[0].OfferToUser.status != 0){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.alreadyDone'
            }
        }
        return UserService.getUser(user).then(function(user){
            return offer.addUser(user, {
                status: 2,
                redeemStart: new Date()
            });
        });
    });
};

exports.endRedeem = function(offerId, user){
    return Offer.find({
        where: {
            id: offerId
        },
        include: {
            model: models.User,
            required: false,
            where: {
                id: user.id
            }
        }
    }).then(function(offer){
        if(!offer){
            throw {
                status: 404
            }
        }
        if(!offer.Users.length){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.notClaimed'
            }
        }
        if(offer.Users[0].OfferToUser.status != 2){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.notStarted'
            }
        }
        return UserService.getUser(user).then(function(user){
            var date1 = offer.Users[0].OfferToUser.redeemStart;
            var date2 = new Date();

            if(date1.getDate() -date2.getDate() <= 15*60*1000){
                return offer.addUser(user, {
                    status: 3,
                    redeemEnd: new Date()
                });
            } else {
                return offer.addUser(user, {
                    status: 0
                }).then(function(){
                    throw {
                        name: 'Client',
                        path: 'id',
                        message: 'drinkz.offers.error.id.timeOut'
                    }
                });
            }
        });
    });
};

exports.cancelRedeem = function(offerId, user){
    return Offer.find({
        where: {
            id: offerId
        },
        include: {
            model: models.User,
            required: false,
            where: {
                id: user.id
            }
        }
    }).then(function(offer){
        if(!offer){
            throw {
                status: 404
            }
        }
        if(!offer.Users.length){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.notClaimed'
            }
        }
        if(offer.Users[0].OfferToUser.status != 2){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.id.notStarted'
            }
        }
        return UserService.getUser(user).then(function(user){
            return offer.addUser(user, {
                status: 0
            });
        });
    });
};

exports.getVenueOffers = function(user){
    return VenueOffer.findAll({
        where: {
            createdBy: user.id
        }
    }).then(function(venueOffers){
        return venueOffers;
    });
};

exports.getOffers = function(query){
    return Offer.findAll({
        limit: query.limit,
        order: [['publishDate', 'DESC']],
        include: [
            models.Media,
            {
                model: models.Product,
                include: [models.SubDrink]
            },
            models.Venue
        ]
    });
};

exports.acceptVenueOffer = function(user, venueOfferId){
    return Venue.find({
        where: {
            userId: user.id
        },
        include: {
            model: VenueOffer,
            where: {
                id: venueOfferId
            }
        }
    }).then(function(venue){
        if(!venue.VenueOffers.length){
            throw {
                name: 'SequelizeValidationError',
                errors: [
                    {
                        path: 'venueOfferId',
                        message: 'drinkz.offers.error.venueOfferId.notFound'
                    }
                ]
            }
        }
        var venueOffer = venue.VenueOffers[0];
        if(venueOffer.OfferToVenue.status != 0){
            throw {
                name: 'Client',
                path: 'id',
                message: 'drinkz.offers.error.venueOfferId.alreadyDone'
            }
        }
        return Offer.create({
            expireDate: venueOffer.expireDate,
            createdBy: user.id,
            quantity: venueOffer.quantity,
            mediaId: venueOffer.mediaId,
            productId: venueOffer.productId,
            cocktailReceiptId: venueOffer.cocktailReceiptId,
            drink: venueOffer.drink,
            publishDate: new Date(),
            venueId: venueOffer.id,
            claimsCount: 0
        }).then(function(offer){
            venueOffer.OfferToVenue.status = 1;
            return venueOffer.OfferToVenue.save().then(function(){
                return offer;
            })
        });
    });
};

module.exports = exports;