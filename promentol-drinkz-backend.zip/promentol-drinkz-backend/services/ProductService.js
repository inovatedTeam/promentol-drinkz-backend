"use strict";

var Promise = require('bluebird');
var Product = require('../models').Product;
var models = require('../models');
var validator = require('validator');
var exports = {};

exports.searchProducts = function (searchData) {
    var whereCause = {};
    if(searchData.drinkId && validator.isInt(searchData.drinkId)){
        whereCause.drinkId = searchData.drinkId;
    }
    if(searchData.subDrinkId){
        if(validator.isInt(searchData.subDrinkId)){
            searchData.subDrinkId = [ searchData.subDrinkId ];
        }
        whereCause.subDrinkId = {
            $in: searchData.subDrinkId
        };
    }
    if(searchData.brandId && validator.isInt(searchData.brandId)){
        whereCause.brandId = searchData.brandId;
    }
    if(searchData.favorId && validator.isInt(searchData.favorId) ){
        whereCause.favorId = searchData.favorId;
    }
    if(searchData.name){
        whereCause.name = {
            $iLike: '%'+searchData.name+'%'
        };
    }
    return Product.findAll({
        where: whereCause
    });
};

exports.getMediaByProductId = function(productId){
    return Product.find({
        where: {
            id: productId
        },
        include: [
            models.Media
        ]
    }).then(function(product){
        if(!product){
            throw {
                status: 404
            }
        }
        return product.Media;
    });
};

module.exports = exports;