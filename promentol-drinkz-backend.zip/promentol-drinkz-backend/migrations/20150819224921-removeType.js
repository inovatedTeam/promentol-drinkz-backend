'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offersForVenues', 'type').then(function(){
      return queryInterface.removeColumn('offersForVenues', 'claimsCount');
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offersForVenues', 'type', Sequelize.ENUM("cocktail", "product")).then(function(){
      return queryInterface.addColumn('offersForVenues', 'claimsCount', Sequelize.INTEGER);
    });
  }
};
