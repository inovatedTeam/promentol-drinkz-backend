'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.dropTable('receiptProducts').then(function(){
      return queryInterface.addColumn('receipts', 'productId', Sequelize.INTEGER);
    })
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.createTable('receiptProducts', {
      receiptId: {
        type: Sequelize.INTEGER,
        primaryKey: true
      },
      productId: {
        type: Sequelize.INTEGER,
        primaryKey: true
      }
    }).then(function(){
      return queryInterface.removeColumn('receipts', 'productId');
    })
  }
};
