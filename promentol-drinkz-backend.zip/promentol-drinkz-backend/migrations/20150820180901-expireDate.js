'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'expireDate').then(function(){
      return queryInterface.addColumn('offers', 'expireDate', Sequelize.DATE);
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'expireDate').then(function(){
      return queryInterface.addColumn('offers', 'expireDate', Sequelize.INTEGER);
    });
  }
};
