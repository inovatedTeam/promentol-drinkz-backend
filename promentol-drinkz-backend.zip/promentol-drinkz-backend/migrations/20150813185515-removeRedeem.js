'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.removeColumn('offerToManager', 'claimDate').then(function(){
        return queryInterface.removeColumn('offerToManager', 'redeemStart').then(function(){
          return queryInterface.removeColumn('offerToManager', 'redeemEnd').then(function(){
            return queryInterface.addColumn('offerToManager', 'acceptDate', Sequelize.INTEGER);
          });
        })
      });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offerToManager', 'claimDate', Sequelize.INTEGER).then(function(){
      return queryInterface.addColumn('offerToManager', 'redeemStart', Sequelize.INTEGER).then(function(){
        return queryInterface.addColumn('offerToManager', 'redeemEnd', Sequelize.INTEGER).then(function(){
          return queryInterface.removeColumn('offerToManager', 'acceptDate');
        });
      })
    });
  }
};
