'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.renameColumn('users', 'password', 'password_hash');
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.renameColumn('users', 'password_hash', 'password');
  }
};
