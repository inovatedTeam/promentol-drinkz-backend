'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.createTable('subDrinks', {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        name: {
          type: Sequelize.STRING
        },
        sortOrder: {
          type: Sequelize.INTEGER
        },
        alias: {
          type: Sequelize.STRING
        },
        drinkId: {
          type: Sequelize.INTEGER
        }
      });

  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.dropTable('subDrinks');
  }
};
