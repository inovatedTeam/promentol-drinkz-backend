'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.createTable('receiptProducts', {
      receiptId: {
        type: Sequelize.INTEGER,
        primaryKey: true
      },
      productId: {
        type: Sequelize.INTEGER,
        primaryKey: true
      }
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.dropTable('receiptProducts');
  }
};
