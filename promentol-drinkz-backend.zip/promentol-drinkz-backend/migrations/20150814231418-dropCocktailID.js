'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'cocktailReceiptId').then(function(){
      return queryInterface.removeColumn('offers', 'drink').then(function(){
        return queryInterface.removeColumn('offersForVenues', 'cocktailReceiptId').then(function(){
          return queryInterface.removeColumn('offersForVenues', 'drink');
        })
      })
    })
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offers', 'cocktailReceiptId', Sequelize.INTEGER).then(function(){
      return queryInterface.addColumn('offers', 'drink', Sequelize.ENUM("drink", 'cocktail')).then(function(){
        return queryInterface.addColumn('offersForVenues', 'cocktailReceiptId', Sequelize.INTEGER).then(function(){
          return queryInterface.addColumn('offersForVenues', 'drink', Sequelize.ENUM("drink", 'cocktail'));
        })
      })
    })
  }
};
