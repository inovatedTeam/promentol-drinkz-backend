'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.addColumn('offers', 'type', Sequelize.ENUM("manager", "distributor")).then(function(){
        return queryInterface.addColumn('offers', 'drink', Sequelize.ENUM("cocktail", "product"));
      });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'type').then(function(){
      return queryInterface.removeColumn('offers', 'drink');
    })
  }
};
