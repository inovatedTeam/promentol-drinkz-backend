'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.dropTable('cocktails').then(function(){
      return queryInterface.dropTable('receipts');
    })
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.createTable('cocktails', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING
      },
      alias: {
        type: Sequelize.STRING
      },
      sortOrder: {
        type: Sequelize.INTEGER
      }
    }).then(function(){
      return queryInterface.createTable('receipts', {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        cocktailId: {
          type: Sequelize.INTEGER
        },
        sortOrder: {
          type: Sequelize.INTEGER
        },
        productId: {
          type: Sequelize.INTEGER
        }
      });
    })
  }
};
