'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.createTable('offersForVenues', {
      id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      quantity: {
        type: Sequelize.INTEGER
      },
      publishDate: {
        type: Sequelize.DATE
      },
      expireDate: {
        type: Sequelize.DATE
      },
      createdBy: {
        type: Sequelize.INTEGER
      },
      mediaId: {
        type: Sequelize.INTEGER
      },
      productID: {
        type: Sequelize.INTEGER
      },
      cocktailReceiptId: {
        type: Sequelize.INTEGER
      },
      drink: {
        type: Sequelize.ENUM("cocktail", "product")
      }
    });
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.dropTable('offersForVenues');
  }
};
