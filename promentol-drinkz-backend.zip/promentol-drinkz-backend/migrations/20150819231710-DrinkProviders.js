'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.createTable('drinkProviders', {
        id: {
          type: Sequelize.INTEGER,
          autoIncrement: true,
          primaryKey: true
        },
        name: {
          type: Sequelize.STRING
        },
        userId: {
          type: Sequelize.INTEGER
        }
      });
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.dropTable('drinkProviders');
  }
};
