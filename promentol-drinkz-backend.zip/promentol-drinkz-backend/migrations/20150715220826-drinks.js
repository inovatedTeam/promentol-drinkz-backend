'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.createTable('drinks', {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true
        },
        name: {
          type: Sequelize.STRING
        },
        sortOrder: {
          type: Sequelize.INTEGER
        },
        alias: {
          type: Sequelize.STRING
        }
      });

  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.dropTable('drinks');
  }
};
