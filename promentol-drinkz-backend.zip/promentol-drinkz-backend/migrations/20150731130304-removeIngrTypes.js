'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.dropTable('ingredientTypes');
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.createTable('ingredientTypes', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING
      }
    })
  }
};
