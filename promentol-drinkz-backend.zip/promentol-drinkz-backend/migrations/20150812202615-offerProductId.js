'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offersForVenues', 'productID').then(function(){
      return queryInterface.addColumn('offersForVenues', 'productId', Sequelize.INTEGER);
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offersForVenues', 'productId').then(function(){
      return queryInterface.removeColumn('offersForVenues', 'productID', Sequelize.INTEGER);
    });
  }
};
