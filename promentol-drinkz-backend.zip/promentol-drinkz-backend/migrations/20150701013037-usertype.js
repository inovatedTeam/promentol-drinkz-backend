'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('users', 'role', Sequelize.ENUM('user', 'manager', 'distributor'));
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('users', 'role');
  }
};
