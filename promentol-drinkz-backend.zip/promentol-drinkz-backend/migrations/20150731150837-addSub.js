'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.addColumn('products', 'subDrinkId', Sequelize.INTEGER);
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.removeColumn('products', 'subDrinkId');
  }
};
