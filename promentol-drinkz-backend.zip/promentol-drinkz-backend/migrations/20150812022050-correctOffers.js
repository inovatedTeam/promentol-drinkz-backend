'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offers', 'publishDate', Sequelize.DATE).then(function(){
      return queryInterface.addColumn('offers', 'cocktailReceiptId', Sequelize.INTEGER);
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'publishDate').then(function(){
      return queryInterface.removeColumn('offers', 'cocktailReceiptId');
    });
  }
};
