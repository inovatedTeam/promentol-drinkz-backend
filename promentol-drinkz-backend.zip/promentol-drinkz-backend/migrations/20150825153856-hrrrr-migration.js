'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.addColumn('drinkProviders', 'mediaId', Sequelize.INTEGER);
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.removeColumn('drinkProviders', 'mediaId');
  }
};
