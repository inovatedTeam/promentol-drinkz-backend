'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.addColumn('offers', 'claimsCount', Sequelize.INTEGER).then(function(){
      return queryInterface.addColumn('offersForVenues', 'claimsCount', Sequelize.INTEGER);
    });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'claimsCount').then(function(){
      return queryInterface.removeColumn('offersForVenues', 'claimsCount');
    });
  }
};
