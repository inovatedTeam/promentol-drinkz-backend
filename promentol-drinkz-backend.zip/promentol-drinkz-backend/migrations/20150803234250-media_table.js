'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
    return queryInterface.createTable('media', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING
      },
      mimeType: {
        type: Sequelize.STRING
      },
      folder: {
        type: Sequelize.STRING
      }
    })
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.dropTable('media');
  }
};
