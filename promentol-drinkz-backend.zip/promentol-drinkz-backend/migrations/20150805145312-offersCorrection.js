'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.renameColumn('offers', 'imageId', 'mediaId').then(function() {
        return queryInterface.addColumn('offers', 'productId', Sequelize.INTEGER)
      });
  },

  down: function (queryInterface, Sequelize) {
    return queryInterface.removeColumn('offers', 'productId').then(function(){
      return queryInterface.renameColumn('offers', 'mediaId', 'imageId');
    });
  }
};
