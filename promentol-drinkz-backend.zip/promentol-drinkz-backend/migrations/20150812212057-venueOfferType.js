'use strict';

module.exports = {
  up: function (queryInterface, Sequelize) {
      return queryInterface.addColumn('offersForVenues', 'type', Sequelize.ENUM("cocktail", "product"));
  },

  down: function (queryInterface, Sequelize) {
      return queryInterface.removeColumn('offersForVenues', 'type');
  }
};
