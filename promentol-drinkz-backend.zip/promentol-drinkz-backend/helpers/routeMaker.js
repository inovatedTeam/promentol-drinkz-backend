"use strict";

var Configurator = require('../helpers/configurator');

var exports = {};

exports.getMediaUrl = function (media) {
    if(media.folder == "users"){
        return this.makeUrl('/api/v1/auth/avatar');
    } else {
        return 'https://' + Configurator.get('aws').bucket + '.' +
            Configurator.get('aws').server + '/' + media.folder + '/' + media.name;
    }
};

exports.getPasswordRecoveryUrl = function(code){
    return this.makeUrl('/passwordRecovery/'+code);
};

exports.makeUrl = function(x){
    return Configurator.get('baseUrl') + x;
};

module.exports = exports;