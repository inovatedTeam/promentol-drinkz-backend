$(function(){
    $("#password-reset-form").submit(function(){
        var self = $(this);
        var data = self.serializeArray();
        if(!data[0].value){
            showError("Write a Password");
        } else if(data[0].value.length <6) {
            showError("Password should be at least 6 characters");
        } else if(data[0].value != data[1].value){
            showError("Password mismatch");
        } else {
            $.ajax({
                method: 'POST',
                url: '/api/v1/passwordRecovery/recover',
                data: {
                    password: data[0].value,
                    code: data[2].value
                }
            }).success(function(x){
                self.remove();
                $("#success").show();
            })
        }
        return false;
    });
});

function showError(x){
    alert(x);
}