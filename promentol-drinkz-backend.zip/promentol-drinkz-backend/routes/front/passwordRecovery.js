var express = require('express');
var router = express.Router();
var PasswordService = require('../../services/PasswordService');

router.get('/:code', function(req, res, next) {
    PasswordService.getRequestByCode(req.params.code).then(function (passwordRequest) {
        if(passwordRequest){
            res.render('site/passwordReset', {
                passwordRequest: passwordRequest
            });
        } else {
            next();
        }
    }).catch(next);
});

module.exports = router;
