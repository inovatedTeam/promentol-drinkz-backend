"use strict";

var express = require('express');
var router = express.Router();
var PasswordService = require('../../services/PasswordService');

router.post('/', function(req, res, next){
    PasswordService.addPasswordRequest(req.body.email).then(function(){
        res.send({});
    }).catch(next);
});

router.post('/recover', function(req, res, next){
    if(!req.body.code){
        next({
            name: 'Client',
            message: 'Invalid Code'
        })
    } else {
        PasswordService.recoverPassword(req.body.code, req.body.password).then(function(){
            res.send({});
        }).catch(next);
    }
});

module.exports = router;