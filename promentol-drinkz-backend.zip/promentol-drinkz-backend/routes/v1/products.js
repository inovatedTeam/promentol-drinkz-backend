"use strict";

var express = require('express');
var router = express.Router();
var ProductService = require('../../services/ProductService');

router.get('/', function(req, res, next){
    ProductService.searchProducts(req.query).then(function(products){
        res.send(products);
    }).catch(next);
});

router.get('/:productId/media', function(req, res, next){
    ProductService.getMediaByProductId(req.params.productId).then(function(medias){
        res.send(medias);
    }).catch(next);
});

module.exports = router;