"use strict";

var express = require('express');
var router = express.Router();
var VenueService = require('../../services/VenueService');

router.get('/', function(req, res, next){
    VenueService.getAllVenues(req.query.q, req.query.regionId).then(function(venues){
        res.send(venues)
    }, function(err){
        next(err);
    });
});

module.exports = router;