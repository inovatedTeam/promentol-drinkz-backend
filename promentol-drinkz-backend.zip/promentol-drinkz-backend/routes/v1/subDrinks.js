"use strict";

var express = require('express');
var router = express.Router();
var SubDrinkService = require('../../services/SubDrinkService');

router.get('/', function(req, res, next){
    SubDrinkService.searchSubDrinks(req.query).then(function(subDrinks){
        res.send(subDrinks);
    }).catch(next);
});

module.exports = router;