"use strict";

var express = require('express');
var router = express.Router();
var UserService = require('../../services/UserService');

router.get('/', function(req, res, next){
    if(!req.user){
        next({
            name: 'Unauth'
        })
    } else {
        UserService.getUser(req.user).then(function(user){
            return UserService.authUser(user)
        }).then(function(user){
            res.send(user);
        });
    }
});

router.post('/', function(req, res, next){
    var promise;
    if(req.body.provider == 'email'){
        promise = UserService.loginWithPassword({
            email: req.body.email || "",
            password: req.body.password || ""
        });
    } else if(req.body.provider == 'facebook') {
        promise = UserService.loginWithFacebook(req.body.oauth_token);
    } else if (req.body.provider == 'twitter') {
        promise = UserService.loginWithTwitter(req.body.oauth_token, req.body.oauth_secret);
    }

    if(promise){
        promise.then(function(x){
            res.send(x);
        }).catch(next);
    } else{
        next({
            name: 'Client',
            path: 'provider',
            message: 'drinkz.users.error.provider.invalid'
        });
    }
});

router.post('/user', function(req, res, next){
    UserService.addUserWithAuth({
        email: req.body.email || "",
        name: req.body.name || "",
        password: req.body.password,
        provider: 'email',
        role: 'user'
    }).then(function(auth){
        res.status(201).send(auth);
    }).catch(function(err){
        next(err);
    });
});

module.exports = router;