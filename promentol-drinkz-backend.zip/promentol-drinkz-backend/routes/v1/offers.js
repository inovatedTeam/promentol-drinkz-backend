"use strict";

var express = require('express');
var router = express.Router();
var OfferService = require('../../services/OfferService');

router.post('/', function(req, res, next){
    if(!req.user || req.user.role == 'user'){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.createOffer(req.body, req.user).then(function(offer){
            res.send(offer);
        }).catch(next);
    }
});

router.post('/:offerId/claim', function(req, res, next){
    if(!req.user){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.claimOffer(req.params.offerId, req.user).then(function(offer){
            res.send({});
        }).catch(next);
    }
});

router.post('/:offerId/startRedeem', function(req, res, next){
    if(!req.user){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.startRedeem(req.params.offerId, req.user).then(function(offer){
            res.send({});
        }).catch(next);
    }
});
router.post('/:offerId/endRedeem', function(req, res, next){
    if(!req.user){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.endRedeem(req.params.offerId, req.user).then(function(offer){
            res.send({});
        }).catch(next);
    }
});
router.post('/:offerId/cancelRedeem', function(req, res, next){
    if(!req.user){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.cancelRedeem(req.params.offerId, req.user).then(function(offer){
            res.send({});
        }).catch(next);
    }
});

router.get('/', function(req, res){

    OfferService.getOffers(req.query).then(function(offers){
        res.send(offers);
    });
});

router.get('/my', function(req, res){
    if(!req.user || req.user.role != 'manager') {
        next({
            name: 'Unauth'
        });
    }
    OfferService.getOffersFromVenue(req.user).then(function(offers){
        res.send(offers);
    });
});

module.exports = router;