"use strict";

var express = require('express');
var router = express.Router();
var RegionService = require('../../services/RegionService');

router.get('/', function(req, res, next){
    RegionService.getAllRegions(req.query.q).then(function(regions){
        res.send(regions)
    }, function(err){
        next(err);
    });
});

module.exports = router;