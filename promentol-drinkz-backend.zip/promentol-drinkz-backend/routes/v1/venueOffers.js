"use strict";

var express = require('express');
var router = express.Router();
var OfferService = require('../../services/OfferService');

router.post('/', function(req, res, next){
    if(!req.user || req.user.role == 'user' || req.user.role == 'manager'){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.createVenueOffer(req.body, req.user).then(function(offer){
            res.send(offer);
        }).catch(next);
    }
});

router.get('/', function(req, res, next){
    if(!req.user || req.user.role != 'manager') {
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.getOffersForVenue(req.user).then(function(offers){
            res.send(offers);
        }).catch(next);
    }
});

router.get('/my', function(req, res, next){
    if(!req.user || req.user.role == 'manager' || req.user.role == 'user') {
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.getVenueOffers(req.user).then(function (offers) {
            res.send(offers);
        }).catch(next);
    }
});

router.post('/:venueOfferId/accept', function(req, res, next){
    if(!req.user || req.user.role != "manager"){
        next({
            name: 'Unauth'
        });
    } else {
        OfferService.acceptVenueOffer(req.user, req.params.venueOfferId).then(function(offer){
            res.send(offer);
        }).catch(next);
    }
});

module.exports = router;