"use strict";

var RouteMaker = require('../helpers/routeMaker');

module.exports = function(sequelize, DataTypes){
    var Media = sequelize.define('Media', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING
        },
        mimeType: {
            type: DataTypes.STRING
        },
        folder: {
            type: DataTypes.STRING
        }
    }, {
        tableName: 'media',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                Media.belongsToMany(models.Product, {
                    through: 'productsMedia',
                    foreignKey: 'mediaId',
                    otherKey: 'productId'
                });
                Media.hasMany(models.Offer, {
                    foreignKey: 'mediaId',
                    as: 'Offer'
                });
                Media.hasMany(models.DrinkProvider, {
                    foreignKey: 'mediaId'
                })
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    url: RouteMaker.getMediaUrl(this)
                }
            }
        }
    });
    return Media;
};