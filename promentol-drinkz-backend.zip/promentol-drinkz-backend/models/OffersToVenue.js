"use strict";

module.exports = function(sequelize, DataTypes){
    var OfferToVenue = sequelize.define('OfferToVenue', {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        venueOfferId: {
            type: DataTypes.INTEGER
        },
        venueId: {
            type: DataTypes.INTEGER
        },
        status: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'offersToVenues',
        timestamps: false,
        freezeTableName: true
    });
    return OfferToVenue;
};