"use strict";

module.exports = function(sequelize, DataTypes){

    var OfferToUser = sequelize.define("OfferToUser", {
        offerId: {
            type: DataTypes.INTEGER
        },
        userId: {
            type: DataTypes.INTEGER
        },
        status: {
            type: DataTypes.INTEGER
        },
        claimDate: {
            type: DataTypes.DATE
        },
        redeemStart: {
            type: DataTypes.DATE
        },
        redeemEnd: {
            type: DataTypes.DATE
        }
    }, {
        tableName: 'offerToUser',
        timestamps: false,
        freezeTableName: true
    });

    return OfferToUser;
};