"use strict";

module.exports = function(sequelize, DataTypes){
    var Offer = sequelize.define('Offer', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        quantity: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                isInt: true,
                moreThanZero: function(quantity, next){
                    if(this.quantity < 0){
                        return next('drinkz.offers.error.quantity');
                    }
                    next()
                }
            }
        },
        expireDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        publishDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        createdBy: {
            type: DataTypes.INTEGER
        },
        mediaId: {
            type: DataTypes.INTEGER
        },
        productId: {
            type: DataTypes.INTEGER
        },
        claimsCount: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'offers',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                Offer.belongsTo(models.Media, {
                    foreignKey: 'mediaId'
                });
                Offer.belongsTo(models.Product, {
                    foreignKey: 'productId'
                });
                Offer.belongsTo(models.Venue, {
                    foreignKey: 'venueId'
                });
                Offer.belongsToMany(models.User, {
                    through: 'OfferToUser',
                    foreignKey: 'offerId',
                    otherKey: 'userId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.Product.name,
                    description: this.Product.description,
                    type: this.Product.SubDrink.name,
                    quantity: this.quantity,
                    claimsCount: this.claimsCount,
                    expireDate: this.expireDate,
                    media: this.Medium,
                    provider: this.Venue
                }
            }
        }
    });
    return Offer;
};