"use strict";

module.exports = function(sequelize, DataTypes){
    var VenueOffer = sequelize.define('VenueOffer', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        quantity: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                isInt: true,
                moreThanZero: function(quantity, next){
                    if(this.quantity < 0){
                        return next('drinkz.offers.error.quantity');
                    }
                    next()
                }
            }
        },
        expireDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        publishDate: {
            type: DataTypes.DATE,
            allowNull: false
        },
        createdBy: {
            type: DataTypes.INTEGER
        },
        mediaId: {
            type: DataTypes.INTEGER
        },
        productId: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'offersForVenues',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                VenueOffer.belongsTo(models.Media, {
                    foreignKey: 'mediaId'
                });
                VenueOffer.belongsTo(models.Product, {
                    foreignKey: 'productId'
                });
                VenueOffer.belongsTo(models.User, {
                    foreignKey: 'createdBy'
                });
                VenueOffer.belongsToMany(models.Venue, {
                    through: models.OfferToVenue,
                    foreignKey: 'venueOfferId',
                    otherKey: 'venueId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.Product.name,
                    description: this.Product.description,
                    type: this.Product.SubDrink.name,
                    quantity: this.quantity,
                    claimsCount: this.claimsCount,
                    expireDate: this.expireDate,
                    media: this.Medium,
                    provider: this.User.DrinkProvider
                }
            }
        }
    });
    return VenueOffer;
};