"use strict";

var i18n = require('i18n');
var bcrypt = require('bcrypt');

module.exports = function(sequelize, DataTypes){

    var User = sequelize.define("User", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING,
            validate: {
                notEmpty: {
                    msg: 'drinkz.users.error.name.notEmpty'
                }
            }
        },
        provider: {
            type: DataTypes.ENUM,
            values: ['email', 'facebook', 'twitter'],
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            validate: {
                notEmpty: {
                    msg: 'drinkz.users.error.email.notEmpty'
                },
                isEmail: {
                    msg: 'drinkz.users.error.email.invalidEmail'
                },
                isUniquePerProvider: function(email, next){
                    var self = this;
                    if(self.provider === "email"){
                        User.find({
                            where: {
                                email: email,
                                provider: "email"
                            }
                        }).then(function(user){
                            if(user != null && (self.id == null || self.id != user.id)){
                                return next('drinkz.users.error.email.alreadyExists');
                            }
                            next();
                        });
                    } else {
                        next();
                    }
                }
            }
        },
        password: {
            type: DataTypes.VIRTUAL,
            set: function(val){
                val = val || "";
                this.setDataValue('password',val);
                var salt = bcrypt.genSaltSync(10);
                this.setDataValue('password_hash', bcrypt.hashSync(val, salt))
            },
            validate: {
                notEmpty: {
                    mgs: 'drinkz.users.error.password.notEmpty'
                },
                len: {
                    args: [4, 31],
                    msg: 'drinkz.users.error.password.length'
                }
            }
        },
        password_hash: {
            type: DataTypes.STRING
        },
        oauth_token: {
            type: DataTypes.STRING
        },
        oauth_secret: {
            type: DataTypes.STRING
        },
        role: {
            type: DataTypes.STRING
        },
        vendor_id: {
            type: DataTypes.STRING
        },
        vendor_username: {
            type: DataTypes.STRING
        }
    }, {
        tableName: 'users',
        timestamps: true,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                User.hasMany(models.VenueOffer, {
                    foreignKey: 'createdBy'
                });
                User.hasOne(models.DrinkProvider, {
                    foreignKey: 'userId'
                });
                User.belongsToMany(models.Offer, {
                    through: 'OfferToUser',
                    foreignKey: 'userId',
                    otherKey: 'offerId'
                });
                User.hasMany(models.PasswordRecoveryRequest, {
                    foreignKey: 'userId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                var profileImage;
                if(this.provider == "facebook"){
                    profileImage = "http://graph.facebook.com/"+this.vendor_id+"/picture?type=square"
                }
                if(this.provider == "twitter"){
                    profileImage = "https://twitter.com/"+this.vendor_username+"/profile_image?size=original"
                }
                return {
                    id: this.id,
                    vendor_id: this.vendor_id,
                    vendor_username: this.vendor_username,
                    name: this.name,
                    email: this.email,
                    oauth_token: this.oauth_token,
                    oauth_secret: this.oauth_secret,
                    provider: this.provider,
                    avatar: profileImage,
                    role: this.role
                }
            }
        }
    });

    return User;
};