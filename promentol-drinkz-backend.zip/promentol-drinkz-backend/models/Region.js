"use strict";

module.exports = function(sequelize, DataTypes){

    var Region = sequelize.define("Region", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING,
            validate: {
                notEmpty: {
                    msg: 'drinkz.regions.error.name.notEmpty'
                }
            }
        },
        venueCount: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'regions',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.name,
                    venueCount: this.venueCount
                }
            }
        }
    });

    return Region;
};