"use strict";

module.exports = function(sequelize, DataTypes){
    var DrinkProvider = sequelize.define('DrinkProvider', {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING
        },
        userId: {
            type: DataTypes.INTEGER
        },
        mediaId: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'drinkProviders',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                DrinkProvider.belongsTo(models.User, {
                    foreignKey: 'userId'
                });
                DrinkProvider.belongsTo(models.Media, {
                    foreignKey: 'mediaId'
                })
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.name,
                    media: this.Media
                }
            }
        }
    });
    return DrinkProvider;
};