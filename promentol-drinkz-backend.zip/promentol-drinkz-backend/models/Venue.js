"use strict";

module.exports = function(sequelize, DataTypes){

    var Venue = sequelize.define("Venue", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING,
            validate: {
                notEmpty: {
                    msg: 'drinkz.venues.error.name.notEmpty'
                }
            }
        },
        regionId: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'venues',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                Venue.belongsToMany(models.VenueOffer, {
                    through: models.OfferToVenue,
                    foreignKey: 'venueId',
                    otherKey: 'venueOfferId'
                });
                Venue.hasMany(models.Offer, {
                    foreignKey: 'venueId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.name,
                    regionId: this.regionId
                }
            }
        }
    });

    return Venue;
};