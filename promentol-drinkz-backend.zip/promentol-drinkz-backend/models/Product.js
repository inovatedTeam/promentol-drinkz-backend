"use strict";

module.exports = function(sequelize, DataTypes) {

    var Product = sequelize.define("Product", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING
        },
        sortOrder: {
            type: DataTypes.INTEGER
        },
        brandId: {
            type: DataTypes.INTEGER
        },
        favorId: {
            type: DataTypes.INTEGER
        },
        subDrinkId: {
            type: DataTypes.INTEGER
        },
        drinkId: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'products',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                Product.belongsToMany(models.Media, {
                    through: 'productsMedia',
                    foreignKey: 'productId',
                    otherKey: 'mediaId'
                });
                Product.belongsTo(models.SubDrink, {
                    foreignKey: 'subDrinkId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.name
                }
            }
        }
    });
    return Product;
};