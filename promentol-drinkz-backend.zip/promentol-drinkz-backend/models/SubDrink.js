"use strict";

module.exports = function(sequelize, DataTypes) {

    var SubDrink = sequelize.define("SubDrink", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        name: {
            type: DataTypes.STRING
        },
        sortOrder: {
            type: DataTypes.INTEGER
        },
        alias: {
            type: DataTypes.STRING
        },
        drinkId: {
            type: DataTypes.INTEGER
        }
    }, {
        tableName: 'subDrinks',
        timestamps: false,
        freezeTableName: true,
        classMethods: {
            associate: function(models) {
                SubDrink.hasMany(models.Product, {
                    foreignKey: 'subDrinkId'
                });
            }
        },
        instanceMethods: {
            toJSON: function(){
                return {
                    id: this.id,
                    name: this.name,
                    alias: this.alias,
                    drinkId: this.drinkId
                }
            }
        }
    });
    return SubDrink;
};