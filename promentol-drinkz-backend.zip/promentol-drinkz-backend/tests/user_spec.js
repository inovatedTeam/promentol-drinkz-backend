var frisby = require('frisby');
var Promise = require('bluebird');
var email = Math.random()+'asd@asd.asd';
var userData = {};
var baseUrl = 'http://localhost:3000/api/v1';

function testUserSignUp(){
    frisby
        .create('Test User signup')
        .post(baseUrl+'/auth/user', {
            email: email,
            password: 'asdasd',
            name: 'ASD'
        })
        .expectStatus(201)
        .expectHeaderContains('content-type', 'application/json')
        .expectJSON({
            token: function (val) {
                expect(val).toBeType("string");
            },
            user: {
                id: function (val) {
                    expect(val).toBeNumber()
                },
                name: "ASD",
                email: email,
                provider: "email",
                role: "user"
            }
        })
        .afterJSON(function(data){
            frisby.globalSetup({
                        request: {
                            headers: {
                        authtoken: data.token
                    }
                }
            });
            console.log(data.token);
            userData = data.user;
        })
        .after(testUserAuth)
        .toss();
}

function testUserAuth(){
    frisby
        .create('Test User signup')
        .get(baseUrl+'/auth')
        .expectJSON({
            token: function (val) {
                expect(val).toBeType("string");
            },
            user: {
                id: userData.id,
                name: userData.name,
                email: userData.email,
                provider: userData.provider,
                role: userData.role
            }
        })
        //.after()
        .toss();
}


testUserSignUp();