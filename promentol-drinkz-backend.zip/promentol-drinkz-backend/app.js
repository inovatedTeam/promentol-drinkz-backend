"use strict";

var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var apiMiddle = require('./middleware/api');
var errorReporter = require('./middleware/error');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var i18n = require('i18n');
var compression = require('compression');

i18n.configure({
    locales: ['en'],
    defaultLocale: 'en',
    directory: __dirname + '/locales'
});

var routes = require('./routes/index');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(i18n.init);
app.use(express.static(path.join(__dirname, 'public')));

app.use(apiMiddle());
app.use(compression());

app.use('/', routes);

var auth = require('./routes/v1/auth');
var regions = require('./routes/v1/regions');
var venues = require('./routes/v1/venues');
var products = require('./routes/v1/products');
var subDrinks = require('./routes/v1/subDrinks');
var offers = require('./routes/v1/offers');
var venueOffers = require('./routes/v1/venueOffers');
var passwordRecovery = require('./routes/v1/passwordRecovery');

app.use('/api/v1/auth', auth);
app.use('/api/v1/regions', regions);
app.use('/api/v1/venues', venues);
app.use('/api/v1/products', products);
app.use('/api/v1/subDrinks', subDrinks);
app.use('/api/v1/offers', offers);
app.use('/api/v1/venueOffers', venueOffers);
app.use('/api/v1/passwordRecovery', passwordRecovery);


var frontPasswordRecovery = require('./routes/front/passwordRecovery');

app.use('/passwordRecovery', frontPasswordRecovery);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

app.use(errorReporter());

module.exports = app;
